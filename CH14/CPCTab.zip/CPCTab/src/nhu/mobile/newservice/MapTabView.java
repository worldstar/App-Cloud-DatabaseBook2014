package nhu.mobile.newservice;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;
import android.view.Menu;
import android.widget.TextView;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.LocationSource;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;



public class MapTabView extends locationDetection implements LocationSource, LocationListener{
	private GoogleMap map;
	final int RequestGooglePlayService = 1;
	TextView textView1;
	List<Marker> mapMarker = null;	

	searchNearestStation searchNearestStation1;
	private ArrayList<rawData> NearestStations = new ArrayList<rawData>();
	static final LatLng INITLOCATION = new LatLng(24.163591,120.681764);
	private HashMap<String,rawData> nowStations = null;
	MarkerClickEvent mce = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		map = ((MapFragment) getFragmentManager().findFragmentById(R.id.map)).getMap();
        map.getUiSettings().setZoomControlsEnabled(true);  
        map.animateCamera(CameraUpdateFactory.newLatLngZoom(INITLOCATION,10), 2000, null);
        map.setMyLocationEnabled(true);
        
        textView1 = (TextView) findViewById(R.id.textview2); 
        mce = new MarkerClickEvent(this);
        
        locateMyPosition();//定義於locationDetection中，抓取目前的位置資訊                   
        if(location1 != null){
        	LatLng mapCenter = new LatLng(location1.getLatitude(), location1.getLongitude());       
            map.moveCamera(CameraUpdateFactory.newLatLngZoom(mapCenter, 12));
            
            
            locationManager1.requestLocationUpdates(600000, 1000, myCriteria1, this, null);
        	setMapCenter(location1);       	
            //locationManager1.requestLocationUpdates(locationPrivider1, 600000, 1000, locationListener1);                        
            searchNearByStations();  
            
            
        }
        else
        {
          textView1.setText("Not found");
        } 
        
        map.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
			
			@Override
			public boolean onMarkerClick(Marker marker) {
				final rawData data = nowStations.get(marker.getSnippet());
				
				AlertDialog.Builder dialog = new AlertDialog.Builder(MapTabView.this);		  	  
				  dialog.setPositiveButton("確認",
						    new DialogInterface.OnClickListener(){
				        	public void onClick(
				            DialogInterface dialoginterface, int i){
				        		//Blank content
				            }
				  });
				  final String options[] = new String[]{"導航至此","撥電話: "+data.getPhoneNumber(), "看是否有Google街景圖"};	 
				  dialog.setItems(options, new DialogInterface.OnClickListener(){
			          
			          public void onClick(DialogInterface dialog, int index){
			              //當使用者點選對話框時，顯示使用者所點選的項目
			              //Toast.makeText(MainActivity.this, "您選擇的是"+items[index], Toast.LENGTH_SHORT).show();
			        	  
			        	  if(index ==0){//Route to the location
			        		  mce.clickOnAndroidRoute(location1.getLatitude(), location1.getLongitude(), data.getLat(), data.getLng());
			        	  }
			        	  else if(index ==1){//make a call
			        		  mce.clickOnAndroidPhone(data.getPhoneNumber());
			        	  }
			        	  else{
			        		  mce.showStreetView( data.getLat(), data.getLng());
			        	  }
			          }
			       });
				  
				  dialog.setTitle(marker.getTitle());
				  //dialog.setMessage(item.getSnippet());
				  dialog.show();
				
				
				return false;
			}
		});		
	}

	public void setMapCenter(Location location1) {  
    	mapMarker = new ArrayList<Marker>();
    	//Drawable drawable = this.getResources().getDrawable(R.drawable.car);
        //Drawable drawableCoin = this.getResources().getDrawable(R.drawable.coins);
        //Drawable drawableAbout = this.getResources().getDrawable(R.drawable.information);
        
        LatLng latlng = new LatLng(location1.getLatitude(),location1.getLongitude());
        textView1.setText("經緯度: ("+latlng.latitude+", "+latlng.latitude+")"); 
        
        map.clear();
        map.animateCamera(CameraUpdateFactory.newLatLngZoom(latlng,12), 2000, null);
        mapMarker.add(map.addMarker(new MarkerOptions()
        .position(latlng)
        .title("目前所在位置")
        .anchor(0.5f, 1)
        .icon(BitmapDescriptorFactory.fromBitmap(BitmapFactory.decodeResource(getResources(),R.drawable.car)))));
    	        	             	    
    }
    
    public void searchNearByStations(){    	
        searchNearestStation1 = new searchNearestStation();
        searchNearestStation1.setNumberOfNearestStations(getNumberOfNearestStations());
        searchNearestStation1.initSearch();
        searchNearestStation1.startToFind(new LatLng(location1.getLatitude(),location1.getLongitude()));
        NearestStations = searchNearestStation1.getNearestStations();
        
        nowStations = new HashMap<String, rawData>();
        for(int i=0;i<NearestStations.size();i++){
        	nowStations.put(NearestStations.get(i).getPhoneNumber(),NearestStations.get(i));
        }
        
        showOnMap();    	             
    }
    
    public int getNumberOfNearestStations(){
		String PREFS_NAME = "nhu.mobile.cpc"; 
		SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);	
		return settings.getInt("numberOfStations", 8);
	} 
    
    public void showOnMap() {    	
    	
        for(int i = 0 ; i < NearestStations.size() ; i ++){
        	rawData rawData1 = NearestStations.get(i);
        	Marker item = map.addMarker(new MarkerOptions()
        	.position(rawData1.getLatLng())
        	.title(rawData1.getAddress())
        	.snippet(rawData1.getPhoneNumber())
        	.anchor(0.5f, 1)
        	.icon(BitmapDescriptorFactory.fromBitmap(BitmapFactory.decodeResource(getResources(),R.drawable.icon))));                       
        	mapMarker.add(item);                    
        } 
    } 	

    
    @Override
	protected void onResume() {
	  super.onResume();
	  
	  int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(getApplicationContext());	  
	  if(resultCode == ConnectionResult.SUCCESS){   	   
	     locationManager1.requestLocationUpdates(600000, 1000, myCriteria1, this, null);	   	   
	     map.setLocationSource(this);	   
	  }
	  else
	  {
	     GooglePlayServicesUtil.getErrorDialog(resultCode, this, RequestGooglePlayService); 
	  }
	  
	}
	 
	 @Override
	 protected void onPause() {
	    map.setLocationSource(null);
	    locationManager1.removeUpdates(this);
	     
	    super.onPause();
	 }	
	 
	/**********The methods belonged to LocationSource.**********/
	@Override
	public void activate(OnLocationChangedListener listener) {
		myLocationListener = listener;		
	}

	@Override
	public void deactivate() {
		myLocationListener = null;			
	}	 

	/**********The methods belonged to LocationListener.**********/
	@Override
	public void onLocationChanged(Location location) {
    	LatLng mapCenter = new LatLng(location1.getLatitude(), location1.getLongitude());       
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(mapCenter, 12)); 
        
        if (myLocationListener != null) {
        	 myLocationListener.onLocationChanged(location);
        }        
	}

	@Override
	public void onProviderDisabled(String provider) {
		location1 = null; 
	}

	@Override
	public void onProviderEnabled(String provider) {
		
	}

	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.map_tab_view, menu);
		return true;
	}

}
