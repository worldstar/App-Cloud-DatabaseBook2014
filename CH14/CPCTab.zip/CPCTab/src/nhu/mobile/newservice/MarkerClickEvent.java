package nhu.mobile.newservice;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;

public class MarkerClickEvent {
	
	Context mContext;
	private Handler mHandler = new Handler();
	
	public MarkerClickEvent(Context context){
		mContext = context;
	}
	
	public void clickOnAndroidRoute(double startLat, double startLng, double endLat, double endLng) {        	
    	final String routeUrl = "http://maps.google.com/maps?f=d&saddr="+startLat*1E6+","+startLng*1E6+
								"&daddr="+endLat*1E6+","+endLng*1E6+"&hl=tw";        	
        mHandler.post(new Runnable() {
            public void run() {                	
            	Uri uri = Uri.parse(routeUrl);  
            	Intent it = new Intent(Intent.ACTION_VIEW, uri);  
            	mContext.startActivity(it);            	                      
            }
        });
    } 	
    
    public void clickOnAndroidPhone(String phonenumber) {
    	final String myPhoneNumber = phonenumber;
        mHandler.post(new Runnable() {
            public void run() {
            	Uri uri = Uri.parse("tel:"+myPhoneNumber);  
            	Intent it = new Intent(Intent.ACTION_DIAL, uri);  
            	mContext.startActivity(it);                      
            }
        });
    }   
    
    public void showStreetView(double lat, double lng) {
    	final String StreetViewMsg = "google.streetview:cbll=" + lat +"," + lng + "&cbp=1,30,,0,1.0";
    	
        mHandler.post(new Runnable() {
            public void run() {
            	Uri uri = Uri.parse(StreetViewMsg);  
            	Intent it = new Intent(Intent.ACTION_VIEW, uri);  
            	mContext.startActivity(it);                      
            }
        });
    } 

}
