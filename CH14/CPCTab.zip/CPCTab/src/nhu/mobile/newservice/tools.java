package nhu.mobile.newservice;

import java.util.Calendar;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class tools extends Activity{
	TextView textView1, textView2, textView3;
	Button button1, button2, button3;
	EditText editText1, editText2;
	
    private Button myPickDate;
    private int myYear;
    private int myMonth;
    private int myDay;    

    static final int DATE_DIALOG_ID = 0;	
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);        
        setContentView(R.layout.tools);    
        
        textView1 = (TextView) findViewById(R.id.TextView01);
        textView1.setText("統編1");  
        editText1 = (EditText) findViewById(R.id.EditText01);
        editText1.setText(getPreference("editText1"));
        button1 = (Button) findViewById(R.id.Button01);
        button1.setText("儲存");  
        
        button1.setOnClickListener( new Button.OnClickListener(){
        	public void onClick(View v){
        		String result = editText1.getEditableText().toString();
        		savePreference("editText1", result);
            	Toast.makeText(tools.this, "統編資料"+result+"已儲存", Toast.LENGTH_LONG).show();        		
        	}
        });        

        textView2 = (TextView) findViewById(R.id.TextView02);
        textView2.setText("統編2");    
        editText2 = (EditText) findViewById(R.id.EditText02);
        editText2.setText(getPreference("editText2"));
        button2 = (Button) findViewById(R.id.Button02);
        button2.setText("儲存");         
        
        button2.setOnClickListener( new Button.OnClickListener(){
        	public void onClick(View v){
        		String result = editText2.getEditableText().toString();
        		savePreference("editText2", result);
        		Toast.makeText(tools.this, "統編資料"+result+"已儲存", Toast.LENGTH_SHORT).show();   
        	}
        });                  
        
        textView3 = (TextView) findViewById(R.id.maintenanceText);
        textView3.setText("上次汽機車保養日期: "+getMaintenanceDate());     
        myPickDate = (Button) findViewById(R.id.pickDate);
        myPickDate.setText("設定日期");
        myPickDate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showDialog(DATE_DIALOG_ID);
            }
        });
        
        //現在日期
        final Calendar c = Calendar.getInstance();
        myYear = c.get(Calendar.YEAR);
        myMonth = c.get(Calendar.MONTH);
        myDay = c.get(Calendar.DAY_OF_MONTH);
        
        button3 = (Button) findViewById(R.id.Button03);
        button3.setText("返回");
        
        button3.setOnClickListener( new Button.OnClickListener(){
        	public void onClick(View v){	
        		finish();
        	}
        });       
    }   
	
	public void savePreference(String id, String result){
		String PREFS_NAME = "nhu.mobile.cpc"; 
		SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0); 
		SharedPreferences.Editor editor = settings.edit(); 
		editor.putString(id, result);
		editor.commit();
	} 	
	
	public String getPreference(String id){
		String PREFS_NAME = "nhu.mobile.cpc"; 
		SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);	
		return settings.getString(id, "");
	} 		 
	
    // the callback received when the user "sets" the date in the dialog
    private DatePickerDialog.OnDateSetListener mDateSetListener =
            new DatePickerDialog.OnDateSetListener() {
                public void onDateSet(DatePicker view, int year, 
                                      int monthOfYear, int dayOfMonth) {
                    myYear = year;
                    myMonth = monthOfYear + 1;
                    myDay = dayOfMonth;
                    String combinedResults = myYear+"/"+myMonth+"/"+myDay;
                    saveMaintenanceDate(combinedResults);
                    updateResults();                    
                }                
    };	
            
    @Override
    protected Dialog onCreateDialog(int id) {
        switch (id) {
          case DATE_DIALOG_ID:
        	  //設定今天的日期
        	  Calendar calendar1 = Calendar.getInstance();
        	  myYear = calendar1.get(Calendar.YEAR);
        	  myMonth = calendar1.get(Calendar.MONTH);
        	  myDay = calendar1.get(Calendar.DATE);        	  
        	  return new DatePickerDialog(this,
                        mDateSetListener,
                        myYear, myMonth, myDay);
        }
        return null;
	}
    
	public void saveMaintenanceDate(String result){
		String PREFS_NAME = "nhu.mobile.cpc"; 
		SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0); 
		SharedPreferences.Editor editor = settings.edit(); 
		editor.putString("maintenanceDate", result);
		editor.commit(); 		
	} 	
	
	public String getMaintenanceDate(){
		String PREFS_NAME = "nhu.mobile.cpc"; 
		SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);	
		return settings.getString("maintenanceDate", "year/month/day/");
	}    
    
    private void updateResults() {
    	textView3.setText("上次汽機車保養日期: "+getMaintenanceDate());    
    }	
}
