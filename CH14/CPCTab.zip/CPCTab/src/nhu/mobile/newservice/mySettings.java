package nhu.mobile.newservice;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;


public class mySettings extends Activity{
	TextView textView1;
	Spinner spinner1;	
	Button button1;
	int numberOfStations;
	String numbers[] = new String[]{"", "3", "4", "5", "6", "8", "10", "12", "15", "20"};
		
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);       
        setContentView(R.layout.settings);     
        
        numberOfStations = getPreference();
        numbers[0] = String.valueOf(numberOfStations);//把原本所設定的數值，顯示為Spinner中的第一個數值
        textView1 = (TextView) findViewById(R.id.TextView01);
        textView1.setText("設定預設加油站之數目");      
        
        spinner1 = (Spinner) findViewById(R.id.Spinner01);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, numbers);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner1.setAdapter(adapter);
        spinner1.setOnItemSelectedListener((OnItemSelectedListener) new MySelectedItemListener());                           	   
        
        button1 = (Button) findViewById(R.id.Button01);
        button1.setText("刷新地圖");   
        
        button1.setOnClickListener( new Button.OnClickListener(){
        	public void onClick(View v){  
        		finish();
        		
				Intent intent = new Intent();
				intent.setClass(mySettings.this, TabMapsFrame.class);
				startActivity(intent); 
        	}
        });          
    }   
    
    public class MySelectedItemListener implements OnItemSelectedListener {

        public void onItemSelected(AdapterView<?> parent,
            View view, int pos, long id) {        	
        	Toast.makeText(parent.getContext(), "設定顯示 " +
              parent.getItemAtPosition(pos).toString()+"個加油站", Toast.LENGTH_LONG).show();
        	savePreference(Integer.parseInt(parent.getItemAtPosition(pos).toString()));
        	numbers[0] = parent.getItemAtPosition(pos).toString();
        }

        public void onNothingSelected(AdapterView parent) {
          // Do nothing.
        }
    }        
    
	public void savePreference(int number){
		String PREFS_NAME = "nhu.mobile.cpc"; 
		SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0); 
		SharedPreferences.Editor editor = settings.edit(); 
		editor.putInt("numberOfStations", number);
		editor.commit(); 		
	}    
	
	public int getPreference(){
		String PREFS_NAME = "nhu.mobile.cpc"; 
		SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);	
		return settings.getInt("numberOfStations", 8);
	}   
	

}
