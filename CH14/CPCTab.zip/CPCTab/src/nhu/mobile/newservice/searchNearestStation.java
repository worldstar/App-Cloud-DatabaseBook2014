package nhu.mobile.newservice;

import java.util.ArrayList;

import com.google.android.gms.maps.model.LatLng;



public class searchNearestStation{
	int numberOfNearestStations = 8;
	stationData stationData1;
	private ArrayList<rawData> NearestStations = new ArrayList<rawData>();
	private double tempDistances[];
	
	public void setNumberOfNearestStations(int numberOfNearestStations){
        this.numberOfNearestStations = numberOfNearestStations;
	}
	
	public void initSearch(){
        stationData1 = new stationData();
        stationData1.putData();		
        tempDistances = new double[numberOfNearestStations];
	}
	
	public void startToFind(LatLng center){                
	        
 	   for(int i = 0 ; i < stationData1.getTotalNumber() ; i ++ )
	   {
	       rawData tempRawData = stationData1.getData(i);		       	      
	       
 		   double distance = Math.abs(center.latitude - tempRawData.getLat()) 
	           + Math.abs(center.longitude - tempRawData.getLng());

			if(i < numberOfNearestStations){//Write into the NearestStations array directly.				
				NearestStations.add(tempRawData);
				tempDistances[i] = distance;
			}
			else{
				int largestIndex = getLargestIndex();

	   			if(distance < tempDistances[largestIndex]){//寫入資料
	   				NearestStations.remove(largestIndex);//移除原本的地點
					NearestStations.add(largestIndex, tempRawData);					
					tempDistances[largestIndex] = distance;
	   			}				
			}		
	   }//end for      	   
	}
	
	private int getLargestIndex(){
		double tempDist = 0;
		int largestIndex = 0;
		
		for(int j = 0 ; j < numberOfNearestStations ; j ++ ){
			  if(tempDist  <= tempDistances[j]){
				//To keep the value and index.
				tempDist = tempDistances[j];
				largestIndex = j;					
			  }					
		}			
		
		return largestIndex;
	}
	
	public ArrayList getNearestStations(){
		return NearestStations;
	}
	
}
