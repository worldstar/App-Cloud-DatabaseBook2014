package nhu.mobile.newservice;


import com.google.android.gms.maps.LocationSource.OnLocationChangedListener;
import android.app.AlertDialog;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.support.v4.app.FragmentActivity;

public class locationDetection extends FragmentActivity  {
	public LocationManager locationManager1;
    public Location location1 = null;    
    public String locationPrivider1;
    OnLocationChangedListener myLocationListener = null;
    Criteria myCriteria1;
    
    public void locateMyPosition(){        
        locationManager1 = (LocationManager)getSystemService(LOCATION_SERVICE);                               
        location1 = getMyLocationPrivider(locationManager1, Criteria.ACCURACY_FINE);
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
                
        if(location1 != null){        	
        	//dialog.setTitle("Location is found");
        	//dialog.setMessage("Latitude and Longitude: "+location1.getLatitude()+" "+location1.getLongitude());
        	//dialog.show();             	        	      
        }
        else
        {        	
        	Location location2Coarse = getMyLocationPrivider(locationManager1, Criteria.ACCURACY_COARSE);
        	if(location2Coarse != null){
            	location1 = location2Coarse;
            }   
        	else{
        		dialog.setTitle("Error");
          	  	dialog.setMessage("Location is not found.");
          	  	dialog.show();         		
        	}        	
        }                                        
    }       
    
    public Location getMyLocationPrivider(LocationManager locationManager1, int ACCURACY)
    {
      Location currentLocation = null;
      try
      {
        myCriteria1 = new Criteria();        
        myCriteria1.setAccuracy(ACCURACY);
        myCriteria1.setPowerRequirement(Criteria.POWER_LOW);
        myCriteria1.setAltitudeRequired(false);
        myCriteria1.setBearingRequired(false);
        myCriteria1.setSpeedRequired(false);
        myCriteria1.setCostAllowed(true);            
        locationPrivider1 = locationManager1.getBestProvider(myCriteria1, true);
        currentLocation = locationManager1.getLastKnownLocation(locationPrivider1);
      }
      catch(Exception e)
      {
        e.printStackTrace();
      }
      return currentLocation;
    }    	
}
