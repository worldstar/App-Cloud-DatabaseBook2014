package nhu.mobile.newservice;

import java.util.ArrayList;
import java.util.List;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.LocationSource;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.LocationSource.OnLocationChangedListener;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;


public class myCarLocation extends locationDetection implements LocationSource, LocationListener{
	GoogleMap map;
	//MapController mapController1;	
	Button button1, button2;
	List<Marker> mapMarker = null;	
	final int RequestGooglePlayService = 1;
	
	@Override
	protected void onCreate(Bundle icicle) {
		super.onCreate(icicle);
		setContentView(R.layout.mycarmapview);
		
		map = ((MapFragment) getFragmentManager().findFragmentById(R.id.mapcar)).getMap();
		map.getUiSettings().setZoomControlsEnabled(true);
		map.animateCamera(CameraUpdateFactory.zoomTo(13), 2000, null);
		//mapView.setBuiltInZoomControls(true);     
        //mapView.displayZoomControls(true);
        //mapController1 = mapView.getController();
        //mapController1.setZoom(13);

        locateMyPosition();//定義於locationDetection中，抓取目前的位置資訊                   
        if(location1 != null){
        	LatLng mapCenter = new LatLng(location1.getLatitude(), location1.getLongitude());       
            map.moveCamera(CameraUpdateFactory.newLatLngZoom(mapCenter, 12));
            
        	setMapCenter(location1);        	
        	locationManager1.requestLocationUpdates(600000, 1000, myCriteria1, this, null);                            	
        }         
                
        button1 = (Button) findViewById(R.id.Button01);
        button1.setText("儲存停放位置");  
        
        button1.setOnClickListener( new Button.OnClickListener(){
        	public void onClick(View v){    
                if(location1 != null){
            		String lat = ""+(int)(location1.getLatitude()*1E6);
            		String lng = ""+(int)(location1.getLongitude()*1E6);
            		saveCarLocationInformation("lat", lat);
            		saveCarLocationInformation("lng", lng);
                	Toast.makeText(myCarLocation.this, "經緯度資料已儲存", Toast.LENGTH_LONG).show();      
                	showCarOnMap();                                	
                }           		        	           
        	}
        });             
        
        button2 = (Button) findViewById(R.id.Button02);
        button2.setText("返回");  
        
        button2.setOnClickListener( new Button.OnClickListener(){
        	public void onClick(View v){      
        		finish();
        	}
        });         
        
        int carLat = Integer.parseInt(getCarLocationInformation("lat"));
        int carLng = Integer.parseInt(getCarLocationInformation("lng"));
        
        if(carLat != 0 && carLng != 0){
        	showCarOnMap();
        }
	}	
    
    public void setMapCenter(Location location1) {    	 
    	LatLng point = new LatLng(location1.getLatitude(),location1.getLongitude());    	    	    	
    	//textView1.setText("經緯度: ("+point.getLatitudeE6()+", "+point.getLongitudeE6()+")");  
    	//mapController1.setCenter(point);
    	
    	mapMarker = new ArrayList<Marker>();
    	map.clear();
    	
    	map.animateCamera(CameraUpdateFactory.newLatLngZoom(point,12), 2000, null);
        mapMarker.add(map.addMarker(new MarkerOptions()
        .position(point)
        .title("目前所在位置")
        .anchor(0.5f, 1)
        .icon(BitmapDescriptorFactory.fromBitmap(BitmapFactory.decodeResource(getResources(),R.drawable.people)))));
    	             	             	    
    }
    
	public void saveCarLocationInformation(String item, String value){
		String PREFS_NAME = "nhu.mobile.cpc"; 
		SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0); 
		SharedPreferences.Editor editor = settings.edit(); 
		editor.putString(item, value);
		editor.commit();
	}     
    
	public String getCarLocationInformation(String item){
		String PREFS_NAME = "nhu.mobile.cpc"; 
		SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);	
		return settings.getString(item, "0");
	}    
	
    public void showCarOnMap(){
        if(location1 != null){
        	setMapCenter(location1);                                           
        }   
        
        int lat = Integer.parseInt(getCarLocationInformation("lat"));
        int lng = Integer.parseInt(getCarLocationInformation("lng"));
        
        LatLng carPoint = new LatLng(lat,lng);
        
        Marker item = map.addMarker(new MarkerOptions()
    	.position(carPoint)
    	.title("My Car Location")
    	.anchor(0.5f, 1)
    	.icon(BitmapDescriptorFactory.fromBitmap(BitmapFactory.decodeResource(getResources(),R.drawable.car))));                       
    	mapMarker.add(item); 
    }        
    
    @Override
	protected void onResume() {
	  super.onResume();
	  
	  int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(getApplicationContext());	  
	  if(resultCode == ConnectionResult.SUCCESS){   	   
	     locationManager1.requestLocationUpdates(600000, 1000, myCriteria1, this, null);	   	   
	     map.setLocationSource(this);	   
	  }
	  else
	  {
	     GooglePlayServicesUtil.getErrorDialog(resultCode, this, RequestGooglePlayService); 
	  }
	  
	}
	 
	 @Override
	 protected void onPause() {
	    map.setLocationSource(null);
	    locationManager1.removeUpdates(this);
	     
	    super.onPause();
	 }	
	 
	/**********The methods belonged to LocationSource.**********/
	@Override
	public void activate(OnLocationChangedListener listener) {
		myLocationListener = listener;		
	}

	@Override
	public void deactivate() {
		myLocationListener = null;			
	}	 

	/**********The methods belonged to LocationListener.**********/
	@Override
	public void onLocationChanged(Location location) {
    	LatLng mapCenter = new LatLng(location1.getLatitude(), location1.getLongitude());       
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(mapCenter, 12)); 
        
        if (myLocationListener != null) {
        	 myLocationListener.onLocationChanged(location);
        }        
	}

	@Override
	public void onProviderDisabled(String provider) {
		location1 = null; 
	}

	@Override
	public void onProviderEnabled(String provider) {
		
	}

	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.map_tab_view, menu);
		return true;
	}
    
    	
}

