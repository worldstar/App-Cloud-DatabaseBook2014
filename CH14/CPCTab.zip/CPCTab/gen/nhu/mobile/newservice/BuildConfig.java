/** Automatically generated file. DO NOT MODIFY */
package nhu.mobile.newservice;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}