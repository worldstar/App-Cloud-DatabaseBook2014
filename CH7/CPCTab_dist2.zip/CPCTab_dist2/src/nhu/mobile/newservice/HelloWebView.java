package nhu.mobile.newservice;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;

public class HelloWebView extends Activity {
    /** Called when the activity is first created. */
	WebView mWebView;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);        
        setContentView(R.layout.webviewfile);        
        
        mWebView = (WebView) findViewById(R.id.webview);
        mWebView.getSettings().setJavaScriptEnabled(true);        
        mWebView.loadUrl("file:///android_asset/Price.html");
        //mWebView.setWebViewClient(new HelloWebViewClient());
    }            
}
