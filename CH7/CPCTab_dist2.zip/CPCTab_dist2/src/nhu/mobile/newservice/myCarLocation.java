package nhu.mobile.newservice;

import java.util.ArrayList;
import java.util.List;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;

public class myCarLocation extends locationDetection {
	MapView mapView;
	MapController mapController1;	
	Button button1, button2;
	
	@Override
	protected void onCreate(Bundle icicle) {
		super.onCreate(icicle);
		setContentView(R.layout.mycarmapview);
		
        mapView = (MapView) findViewById(R.id.mapcarview);
        mapView.setBuiltInZoomControls(true);     
        mapView.displayZoomControls(true);
        mapController1 = mapView.getController();
        mapController1.setZoom(13);

        locateMyPosition();//�w�q��locationDetection���A����ثe����m��T                   
        if(location1 != null){
        	setMapCenter(location1);        	
            locationManager1.requestLocationUpdates(locationPrivider1, 600000, 800, locationListener1);                            	
        }         
                
        button1 = (Button) findViewById(R.id.Button01);
        button1.setText("�x�s�����m");  
        
        button1.setOnClickListener( new Button.OnClickListener(){
        	public void onClick(View v){    
                if(location1 != null){
            		String lat = ""+(int)(location1.getLatitude()*1E6);
            		String lng = ""+(int)(location1.getLongitude()*1E6);
            		saveCarLocationInformation("lat", lat);
            		saveCarLocationInformation("lng", lng);
                	Toast.makeText(myCarLocation.this, "�g�n�׸�Ƥw�x�s", Toast.LENGTH_LONG).show();      
                	showCarOnMap();                                	
                }           		        	           
        	}
        });             
        
        button2 = (Button) findViewById(R.id.Button02);
        button2.setText("��^");  
        
        button2.setOnClickListener( new Button.OnClickListener(){
        	public void onClick(View v){      
        		finish();
        	}
        });         
        
        int carLat = Integer.parseInt(getCarLocationInformation("lat"));
        int carLng = Integer.parseInt(getCarLocationInformation("lng"));
        
        if(carLat != 0 && carLng != 0){
        	showCarOnMap();
        }
	}	
    
    public void setMapCenter(Location location1) {    	 
    	GeoPoint point = new GeoPoint((int)(location1.getLatitude()*1E6),(int)(location1.getLongitude()*1E6));    	    	    	
    	//textView1.setText("�g�n��: ("+point.getLatitudeE6()+", "+point.getLongitudeE6()+")");  
    	mapController1.setCenter(point);
    	
        List<Overlay> mapOverlays = mapView.getOverlays();
        mapOverlays.clear();//�M���ثe�Ҧ�������
        Drawable people = this.getResources().getDrawable(R.drawable.people);
        
        HelloItemizedOverlay itemizedoverlay = new HelloItemizedOverlay(people, this);
        itemizedoverlay.setMapCenter(mapView);
        OverlayItem overlayitem = new OverlayItem(point, "�ثe�Ҧb��m", "");                       
        itemizedoverlay.addOverlay(overlayitem);        
        mapOverlays.add(itemizedoverlay);                	             	    
    }
    
	public void saveCarLocationInformation(String item, String value){
		String PREFS_NAME = "nhu.mobile.cpc"; 
		SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0); 
		SharedPreferences.Editor editor = settings.edit(); 
		editor.putString(item, value);
		editor.commit();
	}     
    
	public String getCarLocationInformation(String item){
		String PREFS_NAME = "nhu.mobile.cpc"; 
		SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);	
		return settings.getString(item, "0");
	}    
	
    public void showCarOnMap(){
        if(location1 != null){
        	setMapCenter(location1);                                           
        }    	
        List<Overlay> mapOverlays = mapView.getOverlays();        
        Drawable car = this.getResources().getDrawable(R.drawable.car);  
        HelloItemizedOverlay itemizedoverlay2 = new HelloItemizedOverlay(car, this);
        itemizedoverlay2.setMapCenter(mapView);
        
        int lat = Integer.parseInt(getCarLocationInformation("lat"));
        int lng = Integer.parseInt(getCarLocationInformation("lng"));
        
        GeoPoint carPoint = new GeoPoint(lat, lng);
        
    	OverlayItem overlayitem = new OverlayItem(carPoint, "My Car Location", "");                       
        itemizedoverlay2.addOverlay(overlayitem);                
        mapOverlays.add(itemizedoverlay2);    	       
    }        
    
    /* The location listener */ 
    public final LocationListener locationListener1 =  
    new LocationListener() 
    { 
      //@Override 
      public void onLocationChanged(Location location) 
      { 
        // TODO Auto-generated method stub 
         
        /* Update the location */ 
    	  location1 = location; 
    	  setMapCenter(location1);    	  
      } 
       
      //@Override 
      public void onProviderDisabled(String provider) 
      { 
        // TODO Auto-generated method stub 
    	  location1 = null; 
      } 
       
      //@Override 
      public void onProviderEnabled(String provider) 
      { 
        // TODO Auto-generated method stub 
         
      } 
       
      //@Override 
      public void onStatusChanged(String provider, 
                  int status, Bundle extras) 
      { 
        // TODO Auto-generated method stub          
      } 
    };     
    
	@Override
	protected boolean isRouteDisplayed() {
		return false;
	}		
}

