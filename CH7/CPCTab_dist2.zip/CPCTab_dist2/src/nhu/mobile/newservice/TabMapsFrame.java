package nhu.mobile.newservice;

import android.app.AlertDialog;
import android.app.TabActivity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;

public class TabMapsFrame extends TabActivity {

	TabHost mTabHost;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		Context ctx = this.getApplicationContext();		
		//For the icons of each tab.
        Drawable drawableMap = this.getResources().getDrawable(R.drawable.map);
        Drawable drawableCoin = this.getResources().getDrawable(R.drawable.coins);
        Drawable settings = this.getResources().getDrawable(R.drawable.settings);
        Drawable drawableAbout = this.getResources().getDrawable(R.drawable.information);				
        
		//tab 1
		mTabHost = getTabHost();
		TabSpec tabSpec1 = mTabHost.newTabSpec("tab_test1");
		tabSpec1.setIndicator("�a��", drawableMap);
		Intent i1 = new Intent(ctx, MapTabView.class);
		tabSpec1.setContent(i1);
		mTabHost.addTab(tabSpec1);
		
		//tab2
		mTabHost = getTabHost();
		TabSpec tabSpec2 = mTabHost.newTabSpec("tab_test2");
		tabSpec2.setIndicator("�o��", drawableCoin);
		Intent i2 = new Intent(ctx, HelloWebView.class);
		tabSpec2.setContent(i2);
		mTabHost.addTab(tabSpec2);
					
		//tab 3
		mTabHost = getTabHost();
		TabSpec tabSpec3 = mTabHost.newTabSpec("tab_test3");
		tabSpec3.setIndicator("�]�w", settings);
		Intent i3 = new Intent(ctx, mySettings.class);
		tabSpec3.setContent(i3);
		mTabHost.addTab(tabSpec3);				
		
		//tab4
		mTabHost = getTabHost();
		TabSpec tabSpec4 = mTabHost.newTabSpec("tab_test4");
		tabSpec4.setIndicator("����", drawableAbout);
		Intent i4 = new Intent(ctx, aboutWebView.class);
		tabSpec4.setContent(i4);
		mTabHost.addTab(tabSpec4);	  	
	}	
}