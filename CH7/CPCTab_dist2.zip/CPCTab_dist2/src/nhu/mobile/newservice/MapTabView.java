package nhu.mobile.newservice;

import java.util.ArrayList;
import java.util.List;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;
import android.app.AlertDialog;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

public class MapTabView extends locationDetection {
	MapView mapView;
	MapController mapController1;
	TextView textView1;
	searchNearestStation searchNearestStation1;
	private ArrayList<rawData> NearestStations = new ArrayList<rawData>();
					
	@Override
	protected void onCreate(Bundle icicle) {
		super.onCreate(icicle);
		setContentView(R.layout.maptabview);
		
        mapView = (MapView) findViewById(R.id.mapview);
        mapView.setBuiltInZoomControls(true);      
        mapView.displayZoomControls(true);
        mapController1 = mapView.getController();
        mapController1.setZoom(12);
        
        textView1 = (TextView) findViewById(R.id.textview2);        
        
        locateMyPosition();//�w�q��locationDetection���A����ثe����m��T                   
        if(location1 != null){
        	setMapCenter(location1);        	
            locationManager1.requestLocationUpdates(locationPrivider1, 600000, 1000, locationListener1);                        
            searchNearByStations();        	
        }
        else
        {
          textView1.setText("Not found");
        }                    
	}
	
	@Override
	protected boolean isRouteDisplayed() {
		return false;
	}
    
    public void setMapCenter(Location location1) {    	  	
    	GeoPoint point = new GeoPoint((int)(location1.getLatitude()*1E6),(int)(location1.getLongitude()*1E6));    	    	    	
    	//GeoPoint point = new GeoPoint((int)(23.56985*1E6),(int)(120.49423*1E6));
    	textView1.setText("�g�n��: ("+point.getLatitudeE6()+", "+point.getLongitudeE6()+")");  
    	mapController1.setCenter(point);
    	
        List<Overlay> mapOverlays = mapView.getOverlays();
        mapOverlays.clear();//�M���ثe�Ҧ�������
        Drawable drawable = this.getResources().getDrawable(R.drawable.car);
        Drawable drawableCoin = this.getResources().getDrawable(R.drawable.coins);
        Drawable drawableAbout = this.getResources().getDrawable(R.drawable.information);
        HelloItemizedOverlay itemizedoverlay = new HelloItemizedOverlay(drawable, this);
        itemizedoverlay.setMapCenter(mapView);
        OverlayItem overlayitem = new OverlayItem(point, "�ثe�Ҧb��m", "");                       
        itemizedoverlay.addOverlay(overlayitem);        
        mapOverlays.add(itemizedoverlay);                	             	    
    }  
    
    public void searchNearByStations(){    	
        searchNearestStation1 = new searchNearestStation();
        searchNearestStation1.setNumberOfNearestStations(getNumberOfNearestStations());
        searchNearestStation1.initSearch();
        searchNearestStation1.startToFind(mapView.getMapCenter());
        NearestStations = searchNearestStation1.getNearestStations();
        showOnMap();    	             
    }
    
	public int getNumberOfNearestStations(){
		String PREFS_NAME = "nhu.mobile.cpc"; 
		SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);	
		return settings.getInt("numberOfStations", 8);
	}    
    
    public void showOnMap() {    	
        List<Overlay> mapOverlays = mapView.getOverlays();        
        Drawable drawable2 = this.getResources().getDrawable(R.drawable.icon);
        HelloItemizedOverlay itemizedoverlay2 = new HelloItemizedOverlay(drawable2, this);
        itemizedoverlay2.setMapCenter(mapView);
        
        for(int i = 0 ; i < NearestStations.size() ; i ++){
        	rawData rawData1 = NearestStations.get(i);
        	OverlayItem overlayitem = new OverlayItem(rawData1.getGeoPoint(), rawData1.getAddress(), 
            		rawData1.getPhoneNumber());                       
            itemizedoverlay2.addOverlay(overlayitem);                    
        }  

        mapOverlays.add(itemizedoverlay2);
    }                   
    
    /* The location listener */ 
    public final LocationListener locationListener1 =  
    new LocationListener() 
    { 
      //@Override 
      public void onLocationChanged(Location location) 
      { 
    	  location1 = location; 
    	  setMapCenter(location1);
    	  searchNearByStations();
      } 
       
      //@Override 
      public void onProviderDisabled(String provider) 
      { 
    	  location1 = null; 
      } 
       
      //@Override 
      public void onProviderEnabled(String provider) 
      { 
         
      } 
       
      //@Override 
      public void onStatusChanged(String provider, 
                  int status, Bundle extras) 
      { 
       
      } 
    };     
    
	//@Override
	public boolean onCreateOptionsMenu(Menu menu){		
	    MenuInflater inflater = getMenuInflater();
	    inflater.inflate(R.menu.optionmenu, menu);
		
		return true;        
	}
		
	//@Override
	public boolean onOptionsItemSelected(MenuItem item){
		super.onOptionsItemSelected(item);
		switch(item.getItemId()){
			case R.id.MENU_Position:
		        if(location1 != null){
		        	setMapCenter(location1);
		            searchNearByStations();        	
		        }				
				break;
			case R.id.MENU_tools:
				Intent intent = new Intent();
				intent.setClass(MapTabView.this, tools.class);
				startActivity(intent);
				break;				
			case R.id.MENU_mycar:
				Intent intent2 = new Intent();
				intent2.setClass(MapTabView.this, myCarLocation.class);
				startActivity(intent2);
				break;						
			case R.id.MENU_quit:
				finish();
				break;				
		}
		return true;
	}  	
}
