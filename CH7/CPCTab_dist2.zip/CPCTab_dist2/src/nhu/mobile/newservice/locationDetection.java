package nhu.mobile.newservice;

import com.google.android.maps.MapActivity;

import android.app.AlertDialog;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;

public class locationDetection extends MapActivity{
	public LocationManager locationManager1;
    public Location location1 = null;    
    public String locationPrivider1;
    
    public void locateMyPosition(){        
        locationManager1 = (LocationManager)getSystemService(LOCATION_SERVICE);                               
        location1 = getMyLocationPrivider(locationManager1, Criteria.ACCURACY_FINE);
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
                
        if(location1 != null){        	
        	//dialog.setTitle("Location is found");
        	//dialog.setMessage("Latitude and Longitude: "+location1.getLatitude()+" "+location1.getLongitude());
        	//dialog.show();             	        	      
        }
        else
        {        	
        	Location location2Coarse = getMyLocationPrivider(locationManager1, Criteria.ACCURACY_COARSE);
        	if(location2Coarse != null){
            	location1 = location2Coarse;
            }   
        	else{
        		dialog.setTitle("Error");
          	  	dialog.setMessage("Location is not found.");
          	  	dialog.show();         		
        	}        	
        }                                        
    }
    
    public Location getMyLocationPrivider(LocationManager locationManager1, int ACCURACY)
    {
      Location currentLocation = null;
      try
      {
        Criteria myCriteria1 = new Criteria();        
        myCriteria1.setAccuracy(ACCURACY);
        myCriteria1.setPowerRequirement(Criteria.POWER_LOW);
        myCriteria1.setAltitudeRequired(false);
        myCriteria1.setBearingRequired(false);
        myCriteria1.setSpeedRequired(false);
        myCriteria1.setCostAllowed(true);            
        locationPrivider1 = locationManager1.getBestProvider(myCriteria1, true);
        currentLocation = locationManager1.getLastKnownLocation(locationPrivider1);
      }
      catch(Exception e)
      {
        e.printStackTrace();
      }
      return currentLocation;
    }    
    /*
    public Location getMyLocationPrivider(LocationManager locationManager1)
    {
      Location currentLocation = null;
      try
      {
        Criteria myCriteria1 = new Criteria();
        
        myCriteria1.setAccuracy(Criteria.ACCURACY_FINE);
        myCriteria1.setPowerRequirement(Criteria.POWER_LOW);
        myCriteria1.setAltitudeRequired(false);
        myCriteria1.setBearingRequired(false);
        myCriteria1.setSpeedRequired(false);
        myCriteria1.setCostAllowed(true);            
        locationPrivider1 = locationManager1.getBestProvider(myCriteria1, true);
        currentLocation = locationManager1.getLastKnownLocation(locationPrivider1);
      }
      catch(Exception e)
      {
        e.printStackTrace();
      }
      return currentLocation;
    }       
    
    public Location getMyCoarseLocationPrivider(LocationManager locationManager1)
    {
      Location currentLocation = null;
      try
      {
        Criteria myCriteria1 = new Criteria();
        myCriteria1.setAccuracy(Criteria.ACCURACY_COARSE);
        myCriteria1.setPowerRequirement(Criteria.POWER_LOW);
        myCriteria1.setAltitudeRequired(false);
        myCriteria1.setBearingRequired(false);
        myCriteria1.setSpeedRequired(false);
        myCriteria1.setCostAllowed(true);            
        locationPrivider1 = locationManager1.getBestProvider(myCriteria1, true);
        currentLocation = locationManager1.getLastKnownLocation(locationPrivider1);
      }
      catch(Exception e)
      {
        e.printStackTrace();
      }
      return currentLocation;
    }    
    */
    /* The location listener. It is just an example inside the locationDetection.java.
     * You may implement a new locationListener1 in the child class.  
    
    public LocationListener locationListener1 =  
    new LocationListener() 
    { 
      //@Override 
      public void onLocationChanged(Location location) 
      {          
    	location1 = location;     	
      } 
      
      //@Override 
      public void onProviderDisabled(String provider) 
      { 
    	  location1 = null; 
      } 
       
      //@Override 
      public void onProviderEnabled(String provider) 
      { 
         
      } 
       
      //@Override 
      public void onStatusChanged(String provider, 
                  int status, Bundle extras) 
      { 
       
      } 
    };       
    */
	@Override
	protected boolean isRouteDisplayed() {
		return false;
	}
}
