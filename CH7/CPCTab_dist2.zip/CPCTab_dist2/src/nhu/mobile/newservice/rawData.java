package nhu.mobile.newservice;

import com.google.android.maps.GeoPoint;

public class rawData {
	private String address = "";
	private double lat = 0.0;
	private double lng = 0.0;
	private String phoneNumber = "";
	
	public void setData(double lng, double lat, String address, String phoneNumber){
		this.lng = lng;	
		this.lat = lat;					
		this.address = address;
		this.phoneNumber = phoneNumber;
	}	
	
	public double getLat(){
		return lat;
	}
	
	public double getLng(){
		return lng;
	}	
	
	public GeoPoint getGeoPoint(){
		GeoPoint point = new GeoPoint((int)(lat*1E6), (int)(lng*1E6));
		return point;
	}
	
	public String getAddress(){
		return address;
	}	
	
	public String getPhoneNumber(){
		return phoneNumber;
	}	
}
