package com.example.mymapproject1;

import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.InfoWindowAdapter;
import com.google.android.gms.maps.GoogleMap.OnInfoWindowClickListener;
import com.google.android.gms.maps.LocationSource;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class MainActivity extends locationDetection implements LocationSource, LocationListener{
	String Titles[] = new String[]{"高雄火車站", "澄清湖", "蓮池潭"};
	String Details[] = new String[]{"高市交通樞紐", "又名大貝湖", "有春秋閣與龍虎塔"};
	double coordinates[][] = new double[][]{{22.639253, 120.30179}, {22.66078, 120.35079}, {22.6840336, 120.2967893}};
	final String websites[] = {"http://www.railway.gov.tw/tw/", "http://chengcinglake.water.gov.tw/", "zh.wikipedia.org/zh-tw/蓮池潭"};
	final int RequestGooglePlayService = 1;

	GoogleMap map;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
        // Get a handle to the Map Fragment
        map = ((MapFragment) getFragmentManager()
                .findFragmentById(R.id.map)).getMap();                        
        map.setMyLocationEnabled(true); 
        
        locateMyPosition();//Inherit from locationDetection                
        if(location1 != null){
        	LatLng mapCenter = new LatLng(location1.getLatitude(), location1.getLongitude());       
            map.moveCamera(CameraUpdateFactory.newLatLngZoom(mapCenter, 12));
            locationManager1.requestLocationUpdates(600000, 1000, myCriteria1, this, null);
        }

        for(int i = 0 ; i < Titles.length ; i ++){
        	LatLng location1 = new LatLng(coordinates[i][0], coordinates[i][1]);
        	
            map.addMarker(new MarkerOptions()
            .title(Titles[i])
            .snippet(Details[i])
            .position(location1));	
        }
        
        map.setOnInfoWindowClickListener(new OnInfoWindowClickListener() {
            @Override
            public void onInfoWindowClick(Marker marker) {
                // TODO Auto-generated method stub              
              final LatLng pos = marker.getPosition();
	    	  String message = "This location is at "+ pos.latitude + ", "+ pos.longitude;
	          Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();    
	          
	          String id = marker.getId().substring(1);
	          int index = Integer.parseInt(id);

	          Intent intent = new Intent(Intent.ACTION_VIEW);
	          intent.setData(Uri.parse(websites[index]));
	          startActivity(intent);          
	          Toast.makeText(MainActivity.this, map.getMyLocation().getLatitude()+" "+map.getMyLocation().getLongitude(), Toast.LENGTH_LONG).show();
            }
        });
        
        map.setInfoWindowAdapter(new MyInfoWindowAdapter());
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	public class MyInfoWindowAdapter implements InfoWindowAdapter{
	    private final View infoWindowObject;
	    
	    public MyInfoWindowAdapter(){
			infoWindowObject = getLayoutInflater().inflate(R.layout.myinfowindow, null);
		}
		
		public View getInfoContents(Marker marker) {
			//Title
			TextView title = ((TextView)infoWindowObject.findViewById(R.id.title));
			title.setText(marker.getTitle());
			
			//Details
			TextView details = ((TextView)infoWindowObject.findViewById(R.id.details));
			details.setText(marker.getSnippet());
			
			//Set default image
			ImageView image = ((ImageView)infoWindowObject.findViewById(R.id.imageView1));
			image.setImageDrawable(getResources().getDrawable(R.drawable.ic_launcher));
			   				
		    return infoWindowObject;
		}

		public View getInfoWindow(Marker marker) {

			return null;
		}
	}
	
	@Override
	protected void onResume() {
	  super.onResume();
	  
	  int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(getApplicationContext());	  
	  if(resultCode == ConnectionResult.SUCCESS){   	   
	     locationManager1.requestLocationUpdates(600000, 1000, myCriteria1, this, null);	   	   
	     map.setLocationSource(this);	   
	  }
	  else
	  {
	     GooglePlayServicesUtil.getErrorDialog(resultCode, this, RequestGooglePlayService); 
	  }
	  
	}
	 
	 @Override
	 protected void onPause() {
	    map.setLocationSource(null);
	    locationManager1.removeUpdates(this);
	     
	    super.onPause();
	 }	
	 
	/**********The methods belonged to LocationSource.**********/
	@Override
	public void activate(OnLocationChangedListener listener) {
		myLocationListener = listener;		
	}

	@Override
	public void deactivate() {
		myLocationListener = null;			
	}	 

	/**********The methods belonged to LocationListener.**********/
	@Override
	public void onLocationChanged(Location location) {
    	LatLng mapCenter = new LatLng(location1.getLatitude(), location1.getLongitude());       
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(mapCenter, 12)); 
        
        if (myLocationListener != null) {
        	 myLocationListener.onLocationChanged(location);
        }        
	}

	@Override
	public void onProviderDisabled(String provider) {
		location1 = null; 
	}

	@Override
	public void onProviderEnabled(String provider) {
		
	}

	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
		
	}
}
